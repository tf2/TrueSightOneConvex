##############################################################################################################################################################################	
## CoNVeX Execution	script for DDD - modified for Kim to run on TrueSightOne data 18/09/2015
## Author: Tomas Fitzgerald
## Email: tf2@sanger.ac.uk
## Date: 19/06/2013

require(mgcv)
library(CoNVex, lib.loc="/software/ddd/internal/convex-pipeline/convex-1.0/Rlib")
library(recipeB, lib.loc="/software/ddd/internal/convex-pipeline/convex-1.0/Rlib")
source("convex.master.R")

args<-commandArgs(TRUE)
options(echo = FALSE)

x = as.numeric(Sys.getenv('LSB_JOBINDEX'))
jobid = as.character(Sys.getenv('LSB_JOBID'))
exec_type = as.character(args[1])
workfile = as.character(args[2])
config_file = as.character(args[3])
source(config_file)

if(exec_type=="final") {
	x = 1
}

worklist= read.table(workfile, sep="\t", header=F)
stable_person_id = as.character(worklist[,1])
sanger_id = as.character(worklist[,2])
sample_gender = as.character(worklist[,3])
RDfiles = as.character(worklist[,4])
bamfiles = as.character(worklist[,5])

RDfiles=paste(convex_config$files$outdest, RDfiles, sep="/")
system(paste("mkdir -p ", convex_config$files$dest, sep=""))

l2file = paste(substr(RDfiles[x], 0, nchar(RDfiles[x])-4), "_LR2.dat",sep="")
gamfile = paste(substr(RDfiles[x], 0, nchar(RDfiles[x])-4), "_LR2_GAM.dat",sep="")
callfile = paste(substr(RDfiles[x], 0, nchar(RDfiles[x])-4), "_LR2_GAM_CNV.dat",sep="")
mmfile = paste(substr(RDfiles[x], 0, nchar(RDfiles[x])-4), "_LR2_GAM_CNV_MM.dat",sep="")
intfreqfile = paste(substr(RDfiles[x], 0, nchar(RDfiles[x])-4), "_LR2_GAM_CNV_MM_INTFREQ.dat",sep="")
auto_cor_filename = paste(substr(RDfiles[x], 0, nchar(RDfiles[x])-4), "_autosomes_correlated_samples.dat",sep="")
sex_cor_filename = paste(substr(RDfiles[x], 0, nchar(RDfiles[x])-4), "_sexchromosome_correlated_samples.dat",sep="")
gender = as.character(sample_gender[x])
if(gender=="U") {
	gender = "M"
}

if(exec_type=="readdepth") {
	if(file.exists(as.character(bamfiles[x]))) {
		localbamfile = as.character(bamfiles[x])
		generate_read_depthfile(localbamfile, convex_config$files$regions_file, RDfiles[x])
	} 
} 

if(exec_type=="cnv") {
	if(convex_config$process$do_breakpoint_file) {
		generate_breakpoint_file(RDfiles[x], convex_config$files$BPfile, convex_config)
	}

	if(convex_config$process$do_features_file) {
		generate_feature_file(convex_config$files$regions_file, convex_config$files$features_file)
	}

	if(convex_config$process$do_lr2_file) {
		data = read.table(RDfiles[x], sep="\t", header=F)
		data = generate_l2_file(data, l2file, gender, RDfiles, sample_gender, convex_config)
		write.table(data$data, file=l2file, sep="\t", row.names=F, col.names=F, quote=F)
		write.table(data$auto_files, file=auto_cor_filename, sep="\t", row.names=F, col.names=F, quote=F)
		write.table(data$sex_files, file=sex_cor_filename, sep="\t", row.names=F, col.names=F, quote=F)
	}

	if(convex_config$process$do_gam_file) {
		data = GAMCorrection(l2file,convex_config$files$features_file,RDfiles[x],convex_config$files$BPfile,convex_config$settings$doNorm)	
		write.table(data, file=gamfile, sep="\t", row.names=F, col.names=F, quote=F)
	}

	if(convex_config$process$do_cnv_calling) {
		calls  = SWCNV(
					as.numeric(convex_config$settings$p),
					as.numeric(convex_config$settings$tdel),
					as.numeric(convex_config$settings$tdup),
					as.numeric(convex_config$settings$dv),
					as.character(gamfile),
					as.character(sanger_id[x]),
					as.character(convex_config$files$centromere_regions_file),
					as.character(convex_config$files$output_folder),
					as.character(convex_config$exec$sw_exec));			
		write.table(calls, file=callfile, sep="\t", row.names=F, quote=F)
	}
}


if(exec_type=="annotate") {
	set_env(config=convex_config)
	correlated_files = read.table(auto_cor_filename)[,1]
	GAMfiles = paste(substr(as.character(correlated_files), 0, nchar(as.character(correlated_files))-4), "_LR2_GAM.dat",sep="")
	CNVcallsMM = mean_mad(callfile, GAMfiles, gamfile, convex_config)
	write.table(CNVcallsMM, file=mmfile, sep="\t", row.names=F, quote=F)
}

if(exec_type=="final") {
	annotate_freqs(config=convex_config)
}
##############################################################################################################################################################################	

