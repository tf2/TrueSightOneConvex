##############################################################################################################################################################################
## CoNVeX Config settings for DDD
## Author: Tomas Fitzgerald
## Email: tf2@sanger.ac.uk
## Date: 19/06/2013

convex_config <- list("exec" =	list
									("installpath"="/software/ddd/internal/convex-pipeline/convex-1.0/Rlib/CoNVex/java/lib",
									 "samtools"="/software/ddd/external/applications/samtools/samtools-0.1.18/bin/samtools",
									 "sw_exec"="/software/ddd/internal/convex-pipeline/convex-1.0/Rlib/CoNVex/exec/swa_lin64"),
					
					"files" =	list("ddd_data"="/lustre/scratch113/projects/ddd/users/tf2/dosage_test/dosage_test/archive/",
									 "regions_file"="/lustre/scratch113/projects/ddd/users/tf2/dosage_test/dosage_test/TruSight_One_bait_regions.txt",
									 "irods_bam_store"="/humgen/projects/ddd/improved_BAMs_archive/",
									 "features_file"="/lustre/scratch113/projects/ddd/users/tf2/dosage_test/dosage_test/features.txt",
									 "BPfile"="/lustre/scratch113/projects/ddd/users/tf2/dosage_test/dosage_test/breakpoints.txt",
									 "output_folder"="/lustre/scratch113/projects/ddd/users/tf2/dosage_test/dosage_test/data",
									 "centromere_regions_file"="/software/ddd/internal/convex-pipeline/convex-pipeline-4.0.0/resources/gaps_table_hg19.txt",
									 "dest"="/lustre/scratch113/projects/ddd/users/tf2/dosage_test/dosage_test/data/",
									 "outdest"="/lustre/scratch113/projects/ddd/users/tf2/dosage_test/dosage_test/data"),
	
					"process" = list("check_and_generate_rd_file"=TRUE,
										"do_breakpoint_file"=FALSE,
										"do_features_file"=FALSE,
										"do_lr2_file"=TRUE,
										"do_gam_file"=TRUE,
										"do_cnv_calling"=TRUE,
										"move_to_archive_and_delete"=TRUE),
	
					"settings" = list("column"="5",
										"max_bin_size"="1000",
										"doNorm"="0",
										"min_samples"="10",
										"p"="2",
										"tdel"="5",
										"tdup"="5",
										"dv"="0.5")
					)

##############################################################################################################################################################################
