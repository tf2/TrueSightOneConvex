##############################################################################################################################################################################
## Pipeline functions for CoNVeX execution - DDD
## Author: Tomas Fitzgerald
## Email: tf2@sanger.ac.uk
## Date: 19/06/2013

generate_read_depthfile <- function(bamfile=NULL, baitfile=NULL, outfile=NULL) {
	command = paste("java -Xmx2g ReadDepth -bam_file ", bamfile, " -regions_file ", baitfile, " -rd_file ", outfile, sep="")
	system(command)
}

generate_breakpoint_file <- function(inputfile=NULL, outputfile=NULL, config=NULL) {
	BP = Breakpoints(inputfile, as.numeric(config$settings$max_bin_size)) 
	write.table(BP, file=outputfile, quote = FALSE, sep = "\t", row.names = FALSE, col.names = TRUE)
}	

generate_feature_file <- function(regions_file, features_file) {
	ff = read.table(regions_file, header=T, sep="\t")
	nam = c("rowcount", colnames(ff))
	ff = cbind(1:length(ff[ff[,1]!="Y",1]), ff[ff[,1]!="Y",])
	colnames(ff) = nam
	write.table(ff, file=features_file, sep="\t", row.names=F, quote=F)
}

GAMCorrection <- function(L2Rfile,features_file,RDfile,BPfile,doNorm=0) {
        sampl2r = read.delim(file=L2Rfile, header=FALSE);
        allXSfeat = read.delim(file=features_file, header=TRUE);
        Reads = read.delim(file=RDfile, header=FALSE);
        Breakpoints = read.delim(file=BPfile, header=TRUE);

        # No. of Reads per Target and Cut breaks - break points vector
        ReadsallXS = Reads[rownames(Reads) %in% allXSfeat[,1],] ## MedianReadsInBins, MedianMADInBins, ADMweights, BreakPoints
        nnmax = c(Breakpoints[,2],max(ReadsallXS[,4])+1)

        # Cut the Number of Reads into bins
        xc = cut(ReadsallXS[,4]+0.01,breaks=nnmax)
        xxc_cut = data.frame(seq(1:length(ReadsallXS[,1])),ReadsallXS,xc)
        names(xxc_cut)[length(xxc_cut)] = "CutRanges"
        xcu = sort(unique(xc))

        # Correction
        require(mgcv);
        #model = gam(sampl2r$V1 ~ s(allXSfeat[,5]) + s(allXSfeat[,6],allXSfeat[,7])) # linear correction
        model = gam(sampl2r$V1 ~ s(allXSfeat[,5])) # linear correction - only GC
        CR_MADs = data.frame(xxc_cut[,1:6],model$residual,xxc_cut$CutRanges)
        names(CR_MADs) = c("RowCount","Chr","Start","End","Reads","Depths","ModelResid","CutRanges")

        xclmad = rep(0.0001,length(xcu))
        for(i in 1:length(xcu)) {
                tmpc = CR_MADs[CR_MADs[,8]==xcu[i],]
                xclmad[i] = mad(tmpc[,7],constant=1)
        }
        # Cut Ranges and their ADM weights in one DF
        BPranges = data.frame(xclmad,xcu)
        names(BPranges) = c("SampleMADsInBins","CutRanges")

        # Merge and sort it in Chr ascending order
        xtm = merge(x=CR_MADs,y=BPranges,by="CutRanges")
        xtm = xtm[with(xtm,order(xtm[,2])),]

        ADMRep = EWScore(xtm[,c(3:5,8:9)], doNorm=0);
        return(ADMRep);
}
	
generate_correlation_values <- function(data, RDfiles, config=NULL) {
	cors= vector()
	RDfiles_CutColumn = paste("cut -f", config$settings$column," ",RDfiles,sep="")
	for(y in 1:length(RDfiles_CutColumn)) {
		d = read.table(pipe(RDfiles_CutColumn[y]), header=FALSE, check.names=FALSE, colClasses=c("numeric"), nrows=nrow(data), comment.char="", sep="\t")
		cors[y] = cor(data[data[,1]!="X" & data[,1]!="Y",as.numeric(config$settings$column)]+0.01, d[data[,1]!="X" & data[,1]!="Y",1]+0.01)
	}
return(cors)
}

generate_l2_file <- function(data, l2file, gender, RDfiles, sample_gender, config=NULL) {
	cors = generate_correlation_values(data, RDfiles, config)
	auto_files = RDfiles[order(cors, decreasing=T)]
	sex_files = RDfiles[sample_gender==gender]
	sex_files = sex_files[order(cors[sample_gender==gender], decreasing=T)]
	auto_files=auto_files[2:(as.numeric(config$settings$min_samples)+1)]
	sex_files=sex_files[2:(as.numeric(config$settings$min_samples)+1)]
	big_data = data.frame(NA,do.call('cbind',lapply(paste("cut -f", config$settings$column," ", auto_files,sep=""), function(x) read.table(pipe(x), header=FALSE, check.names=FALSE, colClasses=c("numeric"), nrows=nrow(data), comment.char="", sep="\t")[,1])))[,-(1)]+0.01
	auto_med_data = apply(big_data, 1, median)
	big_data = data.frame(NA,do.call('cbind',lapply(paste("cut -f", config$settings$column," ", sex_files,sep=""), function(x) read.table(pipe(x), header=FALSE, check.names=FALSE, colClasses=c("numeric"), nrows=nrow(data), comment.char="", sep="\t")[,1])))[,-(1)]+0.01
	sex_med_data = apply(big_data, 1, median)
	med_profile = c(auto_med_data[data[,1]!="X" & data[,1]!="Y"], sex_med_data[data[,1]=="X"])
	data = log2((data[data[,1]!="Y",as.numeric(config$settings$column)]+0.01)/med_profile)
return( list("data"=data, "auto_files"=auto_files, sex_files="sex_files" ) )
}

mean_mad <- function(CNVfile, GAMfiles, gamfile, config) {
	CNVcalls = read.table(CNVfile, header=TRUE, sep="\t"); ## All CNV calls
	allXD = GetL2R(config$files$features_file, GAMfiles);
	allX = read.table(config$files$features_file, header=TRUE, sep="\t")[,1:4]; # allXscore = allX;
	L2R <- lapply(allXD, function(z) z[c("V1")]);
	rm(allXD); gc(); # Clean up
	allX = data.frame(allX,do.call('cbind',L2R)); 
	rm(L2R); gc(); # Clean up
	sampledata = read.table(gamfile)[,1:4]
	names(sampledata) = c("chr", "start", "end", "ratio")
	means = vector(); mads = vector();
	
	for(x in 1:length(CNVcalls[,1])) {
		all_log2 = allX[as.character(allX$chr)==as.character(CNVcalls$chr[x]) & allX$start>=CNVcalls$start[x] & allX$end<=CNVcalls$end[x],-(1:4)]
		sample_log2 = mean(sampledata[as.character(sampledata$chr)==as.character(CNVcalls$chr[x]) & sampledata$start>=CNVcalls$start[x] & sampledata$end<=CNVcalls$end[x],4])
		mean_lg2 = apply(all_log2, 2, mean)
		mad_lg2 = mad(mean_lg2)
		means[x] = sample_log2
		mads[x] = mad_lg2
	}	
	CNVcallsMM = data.frame(CNVcalls,means,mads);
	len = length(CNVcallsMM[1,])
	names(CNVcallsMM)[(len-1):len] = c("mean_l2r","mad_l2r")
return(CNVcallsMM)
}

annotate_freqs <- function(config=NULL) {
	files = system(paste("ls ", config$files$outdest ,"/*_LR2_GAM_CNV_MM.dat", sep=""), intern=T)
	alldata = NULL
	for(x in 1:length(files)) {
		d = read.table(files[x], header=T, sep="\t")
		alldata = rbind(alldata, d)
		print(x)
	}
	cc1 = coverlap(alldata, alldata, 0, 0)
	cc2 = coverlap(alldata, alldata, 0.5, 0.5)
	len = length(cc1[1,])
	total_samples = length(unique(alldata$sample_id))
	cc = cbind(cc1[,-((len-2):len)], cc1$ccon/total_samples, cc2$ccon/total_samples)
	names(cc)[(len-2):(len-1)] = c("internal_freq", "rc50_internal_freq")
	
	deldup = rep(-1, length(cc[,1]))
	deldup[cc$cnv_type=="DUP"]=1
	tt = cbind(cc[,1:3], deldup, cc[,-(1:3)])
	tt$chr = as.character(tt$chr)
	tt[tt[,1]=="X",1] = "23"
	tt[tt[,1]=="Y",1] = "24"
	tt$chr = as.numeric(tt$chr)
	freq = toverlap(tt)
	
	cc = freq[,-(4)]
	cc$chr = as.character(cc$chr)
	tt[tt[,1]=="23",1] = "X"
	tt[tt[,1]=="24",1] = "Y"
	len = length(cc[1,])
	names(cc)[(len-3):(len)] = c("rare_forward" ,"rare_backward","common_forward","common_backward")
	
	u = unique(cc$sample_id)
	for(x in 1:length(u)) {
		dat = cc[cc$sample_id==u[x],]
		fi = files[grep(u[x], files)]
		if(length(fi)!=1) { stop ("something is very wrong") }
		newname = paste(substr(fi, 1, nchar(fi)-4), "_INTFREQ.dat", sep="")
		write.table(dat, file=newname, sep="\t", row.names=F, quote=F)
	}	
return(cc)
}
	
##############################################################################################################################################################################
